yyyyyysssssso++++///////////////////////+ys+/+oy++sssssso+//////////+sssssoosssssso+////////+sssssso
y:-----------::://-`                   o:     .ss:------+:        `s-----/s:------o-      /+------oy
y.                -+:                  o:     .sy.       /+`      `s     -so.     `o:   `+/     `+:y
y.     -:::--`      +:         `       `//::://`y.        -o-     `s     -+.o-     `o- `+:     .o- y
y.     +:```-o`     -s   `-://:/::/:-` `://+//:.y.         `+:    `s     -+ `+:     `+:o-     :+`  y
y.     +-   `o.     :o .//-`       `-///+`````:+y.    `:     :+.  `s     -+   //`    `o-    `//`   y
y.     /+:::/-     -o.//`    .---.    .o/     :+y.    `y+`    .+- `s     -+    :+`    `    .+:     y
y.     `````    `-//`//     /+---o:    ./     :+y.    `y-+-    `//.s     -+     -s`       `s-      y
y.             -+o` `s`    `//:::/:     -     :+y.    `y `//`    -os     -+    .+:         :+.     y
y.     /+//.    `:+..o                  .     :+y.    `y   -+.    .+     -+   -+.    `/     .+-    y
y.     +- .+:     `++s     `+///////////:     :+y.    `y    .+:          -+ `//`    `++/     `+/   y
y.     +-  `//      /y-     :+:-----:/+s/     :+y.    `y      :+`        -+.+-     `o- /+`     :+` y
y.     +-    :+`     -s-     `.----.``-y/     :+y.    `y       .o-       -s+.     .o.   -o`     -o.y
y.     +-     .o.     `oo:`          `/y/     :+y.    `y        `+/      -/`     -o`     -o`     `oy
yssssssyo//////+ysssssssyoyso++//++osysoysssssyssssssssy//////////sssssssssssssssy+///////oysssssssy


Hey, you! Haven't you got any shame? These files are illegal and- wait what? They're legal?!
Yes, you read correctly, these files are 100% legit, now. Many thanks to everyone who collaborated to make this release the best one of all.

Included in this package are all the files you'll need to install and run NSP files, as well as some other goodies that are completely optional.

A little information about version numbers, because I've been asked a bit about them;
- If a version goes up by 0.0.1, it means the update is minor and based around infrastructure changes- the experience has not changed. You could skip this without missing much at all.
- If a version goes up by 0.1, it means the update has some new features, but if updating is a big pain for you, you could probably skip it without missing /too/ much.
- If a version goes up by 1, it means that it's a large update, where a new feature/s are so important, that it's highly recommended that you update. Don't miss these big ones!

METEOS RECOMMENDS: "Hey kids, have you used ReiNX? A whole bunch of people worked absurdly hard to get it ready, and poured their blood, sweat and tears into this release. Maybe you can use the files in this pack to use it?"
"Also, I included the Homebrew App Store in this and future releases, to make it easier for you to get more homebrew!"
Smug Bot Sez: "D E V M E N U  is  D E A D M E N U"

CHANGELOG
v3.0.1
- Meteos Recommended Pick: ReiNX
- Changed Tinfoil to a version that isn't broken in places
- Made NOGC patching the default

v3.0
- Meteos Recommended Pick: ReiNX
- Added on-the-fly ES Patching
- Added kernel patching to make LayeredFS work
- Added a function for the user to decide whether to use NOGC or not
- Replaced ROMMenu with Tinfoil
- Updated ReadMe with new information
- Went legit! Banzai!

v2.3
- Meteos Recommended Pick: Super C (NES)
- Integrated new payload with automatic FS patching
- Collapsed folders into something less enormous

v2.2
- Meteos Recommended Pick: The Pokemon Trading Card Game (GBC)
- Updated ReadMe because I can't take a vacation without working a little bit.
- Further split up the patches for added compatibility.


v2.1.1
- Meteos Recommended Pick: Medabots AX: Rokusho Version (GBA)
- Replaced ROMMenu with the correctly-branded one

v2.1
- Meteos Recommended Pick: Medabots AX: Metabee Version (GBA)
- Made credits more professional
- Added the Homebrew App Store to the release to assist the acquistion of new homebrew
- Returned use of HBMenu after reports of some homebrew not working with ROMMenu
- Added the Meteos Recommends! folder

v2.0.1
- Meteos Recommends: Octopath Traveler (NX)
- Changed the folder infrastructure to remove all parts of Tinfoil
- Achieved sentience with Smug Bot

v2.0
- Meteos Recommends: ICEY (NX)
- Replaced HBMenu with ROMMenu - by accident
- Replaced Tinfoil with ROMMenu - deliberately
- Updated ReadMe with Changelog and other goodies
- Sold out and changed the guide to get stickied on GBATemp

v1.5
- Meteos Recommends: Fire Emblem Warriors (NX)
- Added a new version of Tinfoil that can do way more stuff.
- Updated ReadMe
- Started release date SHA256 releases.

v1.4
- Meteos Recommends: STRIKERS1945 (NX)
- Added sigpatch support for 2.x and 3.x
- Added a sick readme with ASCII art done by Darth Meteos himself
- Made Biscuit best girl

v1.3
- ReiNX files tweaked yet again.
- Updated HBMenu to the latest version by TomGER
- Upgraded Tinfoil to a version that can choose install location

v1.2
- Yet another payload file update
- ReiNX files changed to newest master.

v1.1
- Re-integrated sigpatches because that guy was never going to be happy
- Made a small update to the payload file to reduce crashes

vraj.kosto (1.0)
- Removed FS kips from release to make it legal
- Swallowed pride

SPECIAL THANKS
Meteos: 
I'd just like to take a moment to say how great it is to be writing this to you, today. It's currently 5:17AM AEST on the 4th of August, 2018, and I'm looking at the 3.0 release of the Darth Meteos Super Special SD Stash. It's been a rough journey to get here, but we all made it together.
To the team at ReiSwitched, thank you for letting me be such an integral part of this team. To my team at Meteos' Helpers, you have been the most invaluable support and have shown immense patience. Thank you.
And to you, the reader of this ReadMe... Whether this is your first release or your tenth, thank you for supporting ReiNX. You're the person we did all this for and more, and you can count on us still working as hard as we can to bring more and more things for you to enjoy. 
From the bottom of my heart, thank you.

Rei: 
I'd just like to say thanks to everyone that helped in the making of ReiNX. This CFW is my baby, and in such a short time I've gotten a team of people to help manage the codebase and the testing.
At this point, ReiNX is going from a work-in-progress to a full release, which is a big milestone. The community grew overnight and keeps getting bigger, and so has my child. Your positive feedback has been very encouraging.
For those who have used my ReiNand CFW for 3DS, you'll notice ReiNX is a very similar setup in that its moduluar and user friendly. I have many plans for the future of this project and the switch in general so stay tuned.
Also to my donators, you have my sincerest thanks, you guys are awesome!
I hope you keep enjoying ReiNX.

CREDITS
these people are not credited in order of their achievement
- Reisyukaku made this CFW from the ground up
- The team at ReiSwitched helped, too
- Ketzakwatl made ES patches for 2.x and 3.x
- br4z0rf and Calypso from ReiSwitched helped him
- itsjch made the ROMMenu splash screen
- Rajkosto, for all of the issues we've had, made ChoiDujour, an invaluable resource for the Switch community. Thank you very much, man!
- Meteos took the hard work of all these people, slapped it in a zip, and took a lot of the credit
- Zoey held us all together and we aren't ever going to stop missing her.